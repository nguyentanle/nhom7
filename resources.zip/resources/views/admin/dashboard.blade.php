@extends('admin_layout')
@section('admin_content')
<h3>Helllo!</h3>
@endsection