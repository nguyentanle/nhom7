<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Gửi mã khuyến mãi cho khách vip</title>
</head>
<body>
	<h1>GỬi mã cho khách vip <a target="_blank" href="https://hieutantutorial.com/tutorial_youtube/shopbanhanglaravel">https://hieutantutorial.com</a></h1>
		<div class="container">
			<p class="code">Sử dụng Code sau: <span class="promo">BOH232</span></p>
			<p class="expire">Ngày hết hạn code: 30-11-2020</p>
		</div>
</body>
</html>