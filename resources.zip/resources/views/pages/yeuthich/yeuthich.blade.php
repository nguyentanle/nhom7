@extends('layout')
@section('content')
<div class="features_items"><!--features_items-->
        <h2 class="title text-center">Sản phẩm yêu thích</h2>
        <div id="output"></div>                
                      
</div>
                       

@endsection