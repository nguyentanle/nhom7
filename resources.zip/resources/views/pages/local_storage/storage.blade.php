<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<title>Js Storage</title>
</head>
<body>
	<script type="text/javascript">
		localStorage.setItem('name','hieu');
	</script>
</body>
</html>